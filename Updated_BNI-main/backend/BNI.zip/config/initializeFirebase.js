var admin = require("firebase-admin");

var serviceAccount =FIREBASE_SERVICE_ACCOUNT={
 "type": "service_account",
 "project_id": "b-conn-d5f33",
 "private_key_id": "92c7a2364192dd45fdf08d337ba4de8f0c1dc562",
 "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCHTxsxH87D0VXn\nPW/zJzGeX4+rgUuEtHn/DeFgacvVQ8KXXm2FtZJTmGs3ejT4OZPehkDeYXzqmTM0\nPkoc/Bk37wV6aARA1K1DtNgNxv9GbN75R8LSR8Z0ZHWPQruRpo8oyfSoDLpo3Vnq\n/9S9nsMGhE/XjoN+og1bPIWtMR1SPGDRJ6mKYSA5u/D4GTwiDV1sRiTQUzWrUwOY\nKnLutrLg6bxjft89/gBtXB+7p8PNhDzyJy48vZHrew6FtwY6chGF+iAPyC2dSwdm\nhus6N9a6BF42QZU1o6dE6asX1uzfNn/ETSqVeWxSSsUJCuRwp6DGYUYjHSwRfRzO\ndrDOJAj5AgMBAAECggEACaS8LznxSRMpgwO7GlfVQ/sok1RxjEGL86nKwc3Yfq3H\nzR+oQPV/ZSDW/LW417t2y/nCiXbmPxbFx6KW3U5PAnsGZ20evHt2kShEQRBz5NI2\nlAqmxR44ySvYaxTvpwJOxV1GEsIReQ7UQpjoJyQ3tHEH+w4dALtOULiACHzDIQyy\nYL/Fd0X+iDWKWqeXC6DzUwrONmbYInmGNde+45Hxof/UZSy94d9jXgb4ETcYPICD\n5B/Q5YFpC+cmlXtrnwEbGU9ygsmSeWCemjzCPCZWzz65NDsK5LVXyGg4Iv1GoWfM\nLwUasuiWOJbkXZRWFJc9wtMTi2awyfTOcRAALtbglwKBgQC9CgrY78tD2bIstAzk\n40l1ZxP5pO4IAZxm47c4AAnFM2gqHOmMIMiYsG0ihnmvfupTw9P8uDsca5Rd7S0Y\nD3l0NhWf2EGw+kU/BuogWxrShieSrpx/hA9zPkpW6mnMRZIJnCxcJvEgW/HjslQW\njPbXDFJQe/xzlR4MkfcumNHEIwKBgQC3PNdvJK1GTJPHhnzqPz/nQN2on47gVFA9\nEA4pCdU/PEiYS5TkZ4XZvA5z9TgVoFMhxZyW8NuVWnl+jHZlCraVTjfpFFx/osCn\nAyPuyPnU715h+MYU5PLbg+LsV0ufsxh8UtODypqKbxoLiuhn8z0M4aqRN9FWvImS\nodnKrGqSMwKBgCmCpgUjCth4Wka0tswgGMZd/yXnkJlTeTuir13trDeQZUQyGxq5\nLDNTMnPNYbUmwl/odYleDyTbfrXtWeSZqUragX8bJrmtCz2e0BSQzOADs3bjPtxF\nbHsa54oUaW0ArePMVnVZ28MGTaR5STu2cpGgVAb2YuYijXmnJ8ckqZNPAoGAcqw6\nzq2PWu1VloqN5jMLFPg9P+gLDEz3oh9IHVqv/9EERXsXhRFcbPUJvnv6S154aCw5\nYST+5qsmWZIiDf30Yd//kXhSovYBxwNqG2ffIeljkcCUhkL50XLqMqo3A4ybiEJ1\naIcEzBnXnN2jsFpDHKqlihf6hGOdXQy5NeNNFo0CgYBM52Efy1dqi0KrgC+4K9J7\nV/VoEfd3G3eejZDpoZj/+xvHxiONH7qee1VsmK12F3i3EccLwk1uCpOkIDfRc7ws\nJRwtlOqMV1SOQNfDqnPyMyXGQD5lIX0Ho1Y5bTXLGaJ6tPTPZba5CFOQzQ3NHvPj\no+pHdVPncoLELBf2QI8wSA==\n-----END PRIVATE KEY-----\n",
 "client_email": "firebase-adminsdk-dvvpm@b-conn-d5f33.iam.gserviceaccount.com",
 "client_id": "115284900433260680257",
 "auth_uri": "https://accounts.google.com/o/oauth2/auth",
 "token_uri": "https://oauth2.googleapis.com/token",
 "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
 "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-dvvpm%40b-conn-d5f33.iam.gserviceaccount.com",
 "universe_domain": "googleapis.com"
};
  const initializeFirebase = () => {
    if (!admin.apps.length) { 
      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        });
    } 
  };
  
  module.exports = { initializeFirebase };
