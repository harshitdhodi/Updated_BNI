// middleware/roleAuth.js
module.exports = (roles = []) => {
  // Convert single role string to array
  if (typeof roles === 'string') {
    roles = [roles];
  }

  return (req, res, next) => {
    try {
      if (!req.user || !roles.includes(req.user.role)) {
        return res.status(403).json({ message: 'Access denied: insufficient permissions' });
      }
      next();
    } catch (err) {
      console.error('Role auth error:', err);
      res.status(500).json({ message: 'Server error' });
    }
  };
};
