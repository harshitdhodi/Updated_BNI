import React, { useState, useEffect } from "react";
import API from "../../lib/api";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { toast } from "react-toastify";

export default function AddUser() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditMode = Boolean(id);

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "user",
  });

  // -----------------------------
  // 🔹 Fetch user in Edit Mode
  // -----------------------------
  useEffect(() => {
    if (isEditMode) fetchUser();
  }, [id]);

  const fetchUser = async () => {
    try {
      const { data } = await API.get(`/auth/user/${id}`);
      setForm({
        name: data.name,
        email: data.email,
        password: "",
        role: data.role,
      });
    } catch (err) {
      toast.error("Failed to load user");
    }
  };

  // -----------------------------
  // 🔹 Form Submit
  // -----------------------------
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isEditMode) {
        await API.put(`/auth/user/${id}`, form);
        toast.success("User updated successfully");
      } else {
        await API.post("/auth/register", form);
        toast.success("User created successfully");
      }
      navigate("/app/users");
    } catch (err) {
      toast.error(err.response?.data?.message || "Something went wrong");
    }
  };

  return (
    <div className="p-10 animate-fadeIn">

      {/* Back Button */}
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 mb-6 text-green-700 font-medium hover:text-green-900"
      >
        <ArrowLeft size={22} /> Back
      </button>

      <div className="bg-white p-10 rounded-3xl shadow-2xl w-full max-w-2xl mx-auto border border-gray-100">

        <h1 className="text-4xl font-bold text-green-700 mb-2">
          {isEditMode ? "Edit User" : "Add User"}
        </h1>
        <p className="text-gray-500 mb-8">
          {isEditMode ? "Update user details" : "Create a new system user"}
        </p>

        {/* FORM */}
        <form onSubmit={handleSubmit} className="grid gap-6">

          {/* Name */}
          <div>
            <label className="block mb-1 font-medium text-gray-700">
              Full Name
            </label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="border p-3 rounded-lg w-full focus:ring-2 focus:ring-green-300"
              required
            />
          </div>

          {/* Email */}
          <div>
            <label className="block mb-1 font-medium text-gray-700">Email</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="border p-3 rounded-lg w-full focus:ring-2 focus:ring-green-300"
              required
            />
          </div>

          {/* Password — Only in Add Mode */}
          {!isEditMode && (
            <div>
              <label className="block mb-1 font-medium text-gray-700">
                Password
              </label>
              <input
                type="password"
                value={form.password}
                onChange={(e) =>
                  setForm({ ...form, password: e.target.value })
                }
                className="border p-3 rounded-lg w-full focus:ring-2 focus:ring-green-300"
                required={!isEditMode}
              />
            </div>
          )}

          {/* Role */}
          <div>
            <label className="block mb-1 font-medium text-gray-700">
              Select Role
            </label>
            <select
              value={form.role}
              onChange={(e) => setForm({ ...form, role: e.target.value })}
              className="border p-3 rounded-lg w-full focus:ring-2 focus:ring-green-300"
            >
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="bg-green-600 text-white py-3 rounded-xl hover:bg-green-700 text-lg font-semibold transition-all shadow-lg"
          >
            {isEditMode ? "Update User" : "Create User"}
          </button>

        </form>
      </div>
    </div>
  );
}
