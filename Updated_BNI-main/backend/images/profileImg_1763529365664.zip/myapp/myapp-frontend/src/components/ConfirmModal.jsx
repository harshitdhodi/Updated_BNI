import React from "react";

export default function ConfirmModal({ message, onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-2xl shadow-xl w-96 text-center">

        <p className="text-lg font-medium mb-6">{message}</p>

        <div className="flex justify-center gap-4">
          <button
            className="bg-gray-300 px-4 py-2 rounded-lg"
            onClick={onCancel}
          >
            Cancel
          </button>

          <button
            className="bg-red-600 text-white px-4 py-2 rounded-lg"
            onClick={onConfirm}
          >
            Delete
          </button>
        </div>

      </div>
    </div>
  );
}
