import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate, useLocation } from "react-router-dom";
import { Home, Users, LogOut } from "lucide-react";

export default function Sidebar() {
  const { logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();

  const menu = [
    { label: "Dashboard", icon: <Home className="w-5 h-5" />, path: "/dashboard" },
    { label: "User Management", icon: <Users className="w-5 h-5" />, path: "/users" },
  ];

  return (
    <aside className="w-64 bg-white shadow-xl p-6 flex flex-col border-r border-gray-200">

      <h1 className="text-2xl font-bold text-green-700 mb-10">
        Admin Panel
      </h1>

      <nav className="flex flex-col gap-3">
        {menu.map((item, i) => (
          <button
            key={i}
            onClick={() => navigate(item.path)}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition 
              ${
                location.pathname === item.path
                  ? "bg-green-600 text-white shadow"
                  : "text-gray-700 hover:bg-gray-200"
              }
            `}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </nav>

      {/* Logout Bottom */}
      <button
        onClick={logout}
        className="mt-auto flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-3 rounded-xl shadow-md transition duration-300"
      >
        <LogOut className="w-5 h-5" />
        Logout
      </button>
    </aside>
  );
}
