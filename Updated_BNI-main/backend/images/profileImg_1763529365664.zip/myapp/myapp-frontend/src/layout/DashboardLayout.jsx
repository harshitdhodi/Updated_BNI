import React, { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  LogOut,
  UserCircle,
  Menu,
  X,
  ChevronDown,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function DashboardLayout() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const [isOpen, setIsOpen] = useState(true);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="flex min-h-screen bg-gray-100">

      {/* Sidebar */}
      <aside
        className={`${
          isOpen ? "w-64" : "w-20"
        } bg-white/80 backdrop-blur-xl border-r shadow-lg p-5 flex flex-col transition-all duration-300`}
      >
        {/* Sidebar Header */}
        <div className="flex items-center justify-between mb-10">
          {isOpen && (
            <h1 className="text-2xl font-bold text-green-700">Admin Panel</h1>
          )}

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 rounded hover:bg-green-100 transition"
          >
            {isOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {/* Menu */}
        <nav className="flex flex-col gap-3">
          <NavLink
            to="/app/dashboard"
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all
              ${isActive ? "bg-green-600 text-white shadow" : "text-gray-700 hover:bg-green-100"}`
            }
          >
            <LayoutDashboard size={20} />
            {isOpen && "Dashboard"}
          </NavLink>

          <NavLink
            to="/app/users"
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all
              ${isActive ? "bg-green-600 text-white shadow" : "text-gray-700 hover:bg-green-100"}`
            }
          >
            <Users size={20} />
            {isOpen && "User Management"}
          </NavLink>

          <NavLink
            to="/app/profile"
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all
              ${isActive ? "bg-green-600 text-white shadow" : "text-gray-700 hover:bg-green-100"}`
            }
          >
            <UserCircle size={20} />
            {isOpen && "Profile"}
          </NavLink>
        </nav>

        {/* Logout Button */}
        <button
          onClick={handleLogout}
          className="mt-auto flex items-center gap-3 px-4 py-3 bg-red-500 text-white rounded-xl shadow hover:bg-red-600 transition w-full"
        >
          <LogOut size={20} />
          {isOpen && "Logout"}
        </button>
      </aside>

      {/* Main Content */}
      <div className="flex-1">

        {/* Top Header */}
        <header className="bg-white shadow sticky top-0 p-4 flex items-center justify-between">

          {/* Left Side Text */}
          <h2 className="text-xl font-semibold text-gray-700">
            Welcome Back 👋
          </h2>

          {/* RIGHT SIDE PROFILE */}
          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-xl shadow hover:bg-gray-200 transition"
            >
              <UserCircle size={22} className="text-green-700" />

              <span className="font-medium text-gray-700">
                {user?.name || "User"}
              </span>

              <ChevronDown size={18} />
            </button>

            {/* Dropdown */}
            {dropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white shadow-lg rounded-lg border p-2">
                <button
                  onClick={() => navigate("/app/profile")}
                  className="w-full text-left px-4 py-2 rounded-lg hover:bg-gray-100 text-gray-700"
                >
                  Profile
                </button>

                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-red-50 text-red-600"
                >
                  <LogOut size={18} />
                  Logout
                </button>
              </div>
            )}
          </div>

        </header>

        {/* Content */}
        <main className="p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
