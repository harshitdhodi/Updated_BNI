const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');

const User = require('../models/User');
const auth = require('../middleware/auth');
const roleAuth = require('../middleware/roleAuth');

// GET ALL USERS (admin)
router.get('/', auth, roleAuth('admin'), async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json(users);
  } catch (err) {
    console.error('GET /users error', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET single user (admin)
router.get('/:id', auth, roleAuth('admin'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (err) {
    console.error('GET /users/:id error', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// CREATE user (admin)
router.post('/', auth, roleAuth('admin'), async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: 'Name, email and password required' });

    let exist = await User.findOne({ email: email.toLowerCase().trim() });
    if (exist) return res.status(400).json({ message: 'Email already exists' });

    const hashed = await bcrypt.hash(password, 10);
    const user = new User({ name, email: email.toLowerCase().trim(), password: hashed, role: role || 'user' });
    await user.save();
    res.status(201).json({ message: 'User created', user: { id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    console.error('POST /users error', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// UPDATE user (admin)
router.put('/:id', auth, roleAuth('admin'), async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    const update = {};
    if (name) update.name = name;
    if (email) update.email = email.toLowerCase().trim();
    if (role) update.role = role;
    if (password) update.password = await bcrypt.hash(password, 10);

    const user = await User.findByIdAndUpdate(req.params.id, update, { new: true }).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });

    res.json({ message: 'User updated', user });
  } catch (err) {
    console.error('PUT /users/:id error', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// DELETE user (admin)
router.delete('/:id', auth, roleAuth('admin'), async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({ message: 'User deleted' });
  } catch (err) {
    console.error('DELETE /users/:id error', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
