import React, { useEffect, useState } from "react";
import API from "../../lib/api";
import { useNavigate } from "react-router-dom";
import {
  Search,
  SortAsc,
  SortDesc,
  Pencil,
  Trash2,
  UserPlus,
} from "lucide-react";
import { toast } from "react-toastify";
import ConfirmModal from "../../components/ConfirmModal";

export default function UserList() {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);

  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("asc");

  const [page, setPage] = useState(1);
  const [limit] = useState(5);
  const [totalPages, setTotalPages] = useState(1);

  const [selectedId, setSelectedId] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);

  // ---------------------
  // 👉 Fetch Users
  // ---------------------
  const fetchUsers = async () => {
    try {
      const res = await API.get(`/users?page=${page}&limit=${limit}`);

      setUsers(res.data.users || res.data || []);
      setTotalPages(res.data.totalPages || 1);
    } catch (err) {
      toast.error("Failed to load users");
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [page]);

  // ---------------------
  // 👉 Search + Sort
  // ---------------------
  const filtered = users
    .filter(
      (u) =>
        u.name.toLowerCase().includes(search.toLowerCase()) ||
        u.email.toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) =>
      sort === "asc"
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name)
    );

  // ---------------------
  // 👉 Delete User
  // ---------------------
  const handleDelete = async () => {
    try {
      await API.delete(`/users/${selectedId}`);

      toast.success("User deleted successfully");
      setModalOpen(false);
      fetchUsers();
    } catch {
      toast.error("Delete failed");
    }
  };

  return (
    <div className="p-10">

      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-green-700">User Management</h1>

        <button
          onClick={() => navigate("/app/users/add")}
          className="bg-green-600 text-white px-5 py-3 rounded-xl flex items-center gap-2 shadow hover:bg-green-700"
        >
          <UserPlus size={20} /> Add New User
        </button>
      </div>

      {/* Search + Sort */}
      <div className="flex items-center gap-4 mb-6">
        <div className="flex items-center gap-2 bg-white p-3 rounded-xl shadow border">
          <Search size={20} className="text-gray-600" />
          <input
            placeholder="Search user..."
            className="outline-none"
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <button
          className="bg-white shadow p-3 rounded-xl flex items-center gap-2 border"
          onClick={() => setSort(sort === "asc" ? "desc" : "asc")}
        >
          {sort === "asc" ? <SortAsc /> : <SortDesc />}
          Sort
        </button>
      </div>

      {/* User Table */}
      <div className="bg-white p-6 rounded-2xl shadow-xl border">
        <table className="w-full">
          <thead>
            <tr className="border-b bg-green-50">
              <th className="p-3 text-left">Name</th>
              <th className="p-3 text-left">Email</th>
              <th className="p-3 text-left">Role</th>
              <th className="p-3 text-center">Actions</th>
            </tr>
          </thead>

          <tbody>
            {filtered.map((u) => (
              <tr key={u._id} className="border-b hover:bg-gray-50">
                <td className="p-3">{u.name}</td>
                <td className="p-3">{u.email}</td>
                <td className="p-3 capitalize">{u.role}</td>

                <td className="p-3 flex justify-center gap-4">
                  <button
                    onClick={() => navigate(`/app/users/edit/${u._id}`)}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    <Pencil size={20} />
                  </button>

                  <button
                    onClick={() => {
                      setSelectedId(u._id);
                      setModalOpen(true);
                    }}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 size={20} />
                  </button>
                </td>
              </tr>
            ))}

            {filtered.length === 0 && (
              <tr>
                <td
                  colSpan="4"
                  className="text-center py-5 text-gray-500 italic"
                >
                  No users found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex justify-center mt-6 gap-3">
        <button
          disabled={page === 1}
          onClick={() => setPage(page - 1)}
          className="px-4 py-2 bg-gray-200 rounded-lg disabled:opacity-60"
        >
          Previous
        </button>

        <span className="px-4 py-2 bg-green-100 rounded-lg text-green-700">
          Page {page} / {totalPages}
        </span>

        <button
          disabled={page === totalPages}
          onClick={() => setPage(page + 1)}
          className="px-4 py-2 bg-gray-200 rounded-lg disabled:opacity-60"
        >
          Next
        </button>
      </div>

      {modalOpen && (
        <ConfirmModal
          message="Are you sure you want to delete this user?"
          onCancel={() => setModalOpen(false)}
          onConfirm={handleDelete}
        />
      )}
    </div>
  );
}
