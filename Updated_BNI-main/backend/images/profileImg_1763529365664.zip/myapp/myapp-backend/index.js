require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

const app = express();

// Connect Database
connectDB();

// Middlewares
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users')); // ✅ User CRUD Routes

// Example protected dashboard route
const auth = require('./middleware/auth');
app.get('/api/dashboard', auth, (req, res) => {
  res.json({ message: `Welcome to dashboard, user ${req.user.id}` });
});

// Server start
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
