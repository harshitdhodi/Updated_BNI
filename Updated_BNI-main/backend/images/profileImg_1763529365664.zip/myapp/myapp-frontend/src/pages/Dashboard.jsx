import React, { useContext, useEffect, useState } from "react";
import API from "../lib/api";
import { AuthContext } from "../context/AuthContext";

export default function Dashboard() {
  const { user } = useContext(AuthContext);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await API.get("/dashboard");
        setMessage(res.data.message);
      } catch {
        setMessage("Failed to load dashboard.");
      }
    };
    fetchData();
  }, []);

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-200">

      <h2 className="text-3xl font-semibold text-green-700 mb-4">
        Welcome back, {user?.name} 👋
      </h2>

      <p className="text-red-600 font-medium mb-8">
        You are logged in as <strong>{user?.role}</strong>.
      </p>

      <div className="bg-green-50 border border-green-200 rounded-2xl p-6 mb-10 shadow-inner">
        <h3 className="font-semibold text-green-800 text-xl mb-3">
          Protected Message
        </h3>
        <p className="text-gray-700 text-lg">{message}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-green-100 p-6 rounded-2xl text-center shadow-sm">
          <h4 className="text-green-800 font-semibold text-lg mb-2">
            My Profile
          </h4>
          <p className="text-gray-600 text-sm">View your account info.</p>
        </div>

        <div className="bg-green-100 p-6 rounded-2xl text-center shadow-sm">
          <h4 className="text-green-800 font-semibold text-lg mb-2">
            Messages
          </h4>
          <p className="text-gray-600 text-sm">Notifications & updates.</p>
        </div>

        <div className="bg-green-100 p-6 rounded-2xl text-center shadow-sm">
          <h4 className="text-green-800 font-semibold text-lg mb-2">
            Settings
          </h4>
          <p className="text-gray-600 text-sm">Manage preferences.</p>
        </div>
      </div>

    </div>
  );
}
