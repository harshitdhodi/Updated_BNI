import React, { useEffect, useState } from "react";
import API from "../../lib/api";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import { ArrowLeft } from "lucide-react";

export default function EditUser() {
  const navigate = useNavigate();
  const { id } = useParams();

  const [form, setForm] = useState({
    name: "",
    email: "",
    role: "user",
  });

  const fetchUser = async () => {
    try {
      const res = await API.get(`/users/${id}`);
      setForm(res.data);
    } catch {
      toast.error("User not found");
      navigate("/app/users");
    }
  };

  useEffect(() => {
    fetchUser();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await API.put(`/users/${id}`, form);
      toast.success("User updated successfully 🎉");
      navigate("/app/users");
    } catch {
      toast.error("Failed to update user");
    }
  };

  return (
    <div className="p-6 flex justify-center">
      <div className="bg-white/40 backdrop-blur-xl p-10 rounded-3xl shadow-2xl w-full max-w-2xl border border-white/30">

        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-green-700 mb-6 font-semibold hover:underline"
        >
          <ArrowLeft size={20} /> Back
        </button>

        <h1 className="text-3xl font-bold text-green-700 mb-6">Edit User</h1>

        <form onSubmit={handleSubmit} className="grid gap-6">

          <div>
            <label className="font-semibold">Full Name</label>
            <input
              type="text"
              className="border p-3 rounded-lg w-full mt-1 focus:ring-2 focus:ring-green-400"
              value={form.name}
              placeholder="Full Name"
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </div>

          <div>
            <label className="font-semibold">Email Address</label>
            <input
              type="email"
              className="border p-3 rounded-lg w-full mt-1 focus:ring-2 focus:ring-green-400"
              value={form.email}
              placeholder="Email"
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
          </div>

          <div>
            <label className="font-semibold">Role</label>
            <select
              className="border p-3 rounded-lg w-full mt-1 focus:ring-2 focus:ring-green-400"
              value={form.role}
              onChange={(e) => setForm({ ...form, role: e.target.value })}
            >
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
          </div>

          <button
            type="submit"
            className="bg-green-600 text-white py-3 rounded-xl font-semibold hover:bg-green-700 transition-all"
          >
            Update User
          </button>
        </form>
      </div>
    </div>
  );
}
